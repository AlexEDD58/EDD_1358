/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repaso;

/**
 *
 * @author Cabrera
 */
public class Pruebas {
    public static void main(String[] args) {
        Perro mascota = new Perro("Fiddo", 2, "Poddle");
        System.out.println( mascota );
        mascota.setNombre("Max");
        System.out.println( mascota );
        
    }
}
